Client Server API for receiving API request
# ServerClientWeatherExpress
